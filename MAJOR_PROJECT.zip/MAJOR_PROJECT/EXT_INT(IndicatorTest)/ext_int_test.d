.\ext_int_test.o: ext_int_test.c
.\ext_int_test.o: C:\Users\HP\Desktop\keil\ARM\Inc\Philips\lpc21xx.h
.\ext_int_test.o: pin_function_defines.h
.\ext_int_test.o: defines.h
