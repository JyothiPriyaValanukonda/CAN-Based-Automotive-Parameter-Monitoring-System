                   /* ext_int_test.c */
#include <lpc21xx.h>
#include "pin_function_defines.h"
#include "defines.h"

#define LEDS (0xFF<8)

void delay_ms(unsigned dlyMS);

void eint0_isr(void) __irq;
void eint1_isr(void) __irq;

void Enable_EINT0(void);
void Enable_EINT1(void);

int l=0,r=0;

int main()
{
        Enable_EINT0();
        Enable_EINT1();
        while(1)
        {  
           if(l==1&&r==0)
           {
							int i;
							for(i=15;i>=8;i--)
							{
									IOCLR0 = (1<<i);
									delay_ms(120);
									IOSET0 = (1<<i);
							 }
           }
           if(l==0&&r==1)
           {
							int i;
							for(i=8;i<=15;i++)
							{
									IOCLR0 = (1<<i);
									delay_ms(120);
									IOSET0 = (1<<i);
							 }
           }
        }       
}

void delay_ms(unsigned dlyMS)
{
        dlyMS*=12000;
        while(dlyMS--);
}

void eint0_isr(void) __irq
{
				l=!l;
        //CPLBIT(IOPIN0,EINT0_LED);//isr activity
        SSETBIT(EXTINT,0);//clear EINT0 flag
        VICVectAddr=0;//dummy write to clear 
                      //interrupt flag in VIC
        WRITEBYTE(IOPIN0,8,0xFF);
				delay_ms(100);      
}

void eint1_isr(void) __irq
{
				r=!r;
        //CPLBIT(IOPIN0,EINT1_LED);//isr activity
        SSETBIT(EXTINT,1);//clear EINT1 flag
        VICVectAddr=0;//dummy write;
        WRITEBYTE(IOPIN0,8,0xFF);
				delay_ms(100);      
}       

void Enable_EINT0(void)
{
				CFGPIN(PINSEL0,1,FUNC4);
				//SETBIT(IODIR0,EINT0_LED);
				WRITEBYTE(IODIR0,8,0xFF);
				WRITEBYTE(IOPIN0,8,0xFF);
				SSETBIT(VICIntEnable,14);
				VICVectCntl0=0x20|14;
				VICVectAddr0=(unsigned)eint0_isr;
				SCLRBIT(EXTINT,0);
				SETBIT(EXTMODE,0);
				SETBIT(EXTPOLAR,0);
}

void Enable_EINT1(void)
{
				CFGPIN(PINSEL0,3,FUNC4);
				//SETBIT(IODIR0,EINT1_LED);
				WRITEBYTE(IODIR0,8,0xFF);
				WRITEBYTE(IOPIN0,8,0xFF);
				SSETBIT(VICIntEnable,15);
				VICVectCntl1=0x20|15;
				VICVectAddr1=(unsigned)eint1_isr;
				SCLRBIT(EXTINT,1);
				SETBIT(EXTMODE,1);
				SETBIT(EXTPOLAR,1);   
}