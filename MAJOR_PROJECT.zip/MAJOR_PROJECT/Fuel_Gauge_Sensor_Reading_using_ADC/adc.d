.\adc.o: adc.c
.\adc.o: C:\Users\HP\Desktop\keil\ARM\Inc\Philips\LPC21xx.h
.\adc.o: types.h
.\adc.o: defines.h
.\adc.o: adc_defines.h
.\adc.o: delay.h
