.\main.o: main.c
.\main.o: types.h
.\main.o: adc.h
.\main.o: adc_defines.h
.\main.o: uart0.h
.\main.o: delay.h
