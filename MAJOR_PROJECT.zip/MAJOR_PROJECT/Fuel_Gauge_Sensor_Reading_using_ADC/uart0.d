.\uart0.o: uart0.c
.\uart0.o: C:\Users\HP\Desktop\keil\ARM\Inc\Philips\LPC21xx.H
