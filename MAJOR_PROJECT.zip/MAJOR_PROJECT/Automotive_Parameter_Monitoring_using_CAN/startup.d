.\startup.o: Startup.s
