.\main_lcd.o: Main_LCD.c
.\main_lcd.o: C:\Users\HP\Desktop\keil\ARM\Inc\Philips\lpc21xx.h
.\main_lcd.o: lcd.h
.\main_lcd.o: delay.h
.\main_lcd.o: ds18b20.h
