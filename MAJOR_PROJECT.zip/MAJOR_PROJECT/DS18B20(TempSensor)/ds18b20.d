.\ds18b20.o: ds18b20.c
.\ds18b20.o: C:\Users\HP\Desktop\keil\ARM\Inc\Philips\LPC21xx.h
.\ds18b20.o: delay.h
